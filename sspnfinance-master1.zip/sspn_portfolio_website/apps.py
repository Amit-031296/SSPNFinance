from django.apps import AppConfig


class SspnPortfolioWebsiteConfig(AppConfig):
    name = 'sspn_portfolio_website'
