from django.apps import AppConfig


class SspnLeadManagerAppConfig(AppConfig):
    name = 'sspn_lead_manager_app'
